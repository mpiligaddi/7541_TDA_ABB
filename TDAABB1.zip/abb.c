#include "abb.h"
#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>

#define ERROR -1
#define EXITO 0
#define VACIO 0

// -----------------------------------------------------------------------------------
// -----------------------------FUNCIONES PRIVADAS------------------------------------
// -----------------------------------------------------------------------------------

/*
Pre: Recibe un elemento de tipo void*
Post: Crea un nuevo nodo y devuelve el mismo
*/
nodo_abb_t* arbol_nodo_crear(void* elemento) {

	nodo_abb_t* nodo_nuevo = malloc(sizeof(nodo_abb_t));
	if(!nodo_nuevo) {
		return NULL;
	}
	nodo_nuevo->elemento = elemento;
	nodo_nuevo->derecha = NULL;
	nodo_nuevo->izquierda = NULL;
	return nodo_nuevo;

}

/*
Pre: Recibe un nodo de un determinado arbol y un destructor para el elemento del mismo
Post: Libera la memoria reservada para los nodos 
*/
void arbol_nodo_destruir(nodo_abb_t* nodo_arbol, abb_liberar_elemento destructor) {

	if(nodo_arbol->izquierda) {
		arbol_nodo_destruir(nodo_arbol->izquierda, destructor);
	}
	if(nodo_arbol->derecha) {
		arbol_nodo_destruir(nodo_arbol->derecha, destructor);
	}

	if(destructor) {
		destructor(nodo_arbol->elemento);
		free(nodo_arbol);
	}
	return;

}

/*
Pre: Recibe un arbol no NULL, un nodo al mismo y un elemento para insertar en el arbol
Post: Devuelve 0 si pudo insertar el elemento que recibe o -1 si no pudo
*/
int arbol_insertar_aux(abb_t* arbol, nodo_abb_t* nodo, void* elemento) {

	int comparador = arbol->comparador(nodo->elemento, elemento);

	if((comparador == -1) || (comparador == 0)) {
		if(nodo->izquierda == NULL) {
			nodo_abb_t* nodo_nuevo = arbol_nodo_crear(elemento);
			nodo->izquierda = nodo_nuevo;
			return EXITO; 
		}
		return arbol_insertar_aux(arbol, nodo->izquierda, elemento);
	}
	if(comparador == 1) {
		if(nodo->derecha == NULL) {
			nodo_abb_t* nodo_nuevo = arbol_nodo_crear(elemento);
			nodo->derecha = nodo_nuevo;
			return EXITO; 
		}
		return arbol_insertar_aux(arbol, nodo->derecha, elemento);
	}
	return ERROR; 
	
}

/*
Pre: Recibe un arbol no vacio, un nodo al mismo, el padre de ese nodo y la rama que sigue el nodo.
Post: Devuelve 0 si pudo borrar el elemento que recibe o -1 si no pudo
*/
int nodo_borrar_con_1_hijo(abb_t* arbol,nodo_abb_t* nodo_actual,nodo_abb_t* padre_nodo_actual,int rama) {
	//tiene hijo izquierdo
	if((nodo_actual->derecha == NULL) && (nodo_actual->izquierda != NULL)) {
		if(padre_nodo_actual == NULL) {
			arbol->nodo_raiz = nodo_actual->izquierda;
			if(arbol->nodo_raiz->izquierda->elemento == NULL) {
				free(arbol->nodo_raiz->izquierda);
				arbol->nodo_raiz->izquierda = NULL;
			}
			if(arbol->nodo_raiz->derecha->elemento == NULL) {
				free(arbol->nodo_raiz->derecha);
				arbol->nodo_raiz->derecha = NULL;
			}
		}
		else if(rama == -1) {
			padre_nodo_actual->derecha = nodo_actual->izquierda;
		}
		else if(rama == 1) {
			padre_nodo_actual->izquierda = nodo_actual->izquierda;
		}
		if(arbol->destructor) {
			arbol->destructor(nodo_actual->elemento);
			free(nodo_actual);
			return EXITO;
		}
	}
	//tiene hijo derecho
	else if((nodo_actual->derecha != NULL) && (nodo_actual->izquierda == NULL)) {
		if(padre_nodo_actual == NULL) {
			arbol->nodo_raiz = nodo_actual->derecha;
			if(arbol->nodo_raiz->izquierda->elemento == NULL) {
				free(arbol->nodo_raiz->izquierda);
				arbol->nodo_raiz->izquierda = NULL;
			}
			if(arbol->nodo_raiz->derecha->elemento == NULL) {
				free(arbol->nodo_raiz->derecha);
				arbol->nodo_raiz->derecha = NULL;
			}
		}
		else if(rama == -1) {
			padre_nodo_actual->derecha = nodo_actual->derecha;
		}
		else if(rama == 1) {
			padre_nodo_actual->izquierda = nodo_actual->derecha;
		}
		if(arbol->destructor) {
			arbol->destructor(nodo_actual->elemento);
			free(nodo_actual);
			return EXITO;
		}
	}
	return ERROR;
	
}

/*
Pre: Recibe un nodo a un arbol no vacio.
Post: Devuelve el padre del mayor nodo de los menores (predecesor inorden)
*/
nodo_abb_t* nodo_mayor_de_los_menores(nodo_abb_t* nodo) {

	while(nodo->derecha != NULL) {;
		nodo = nodo->derecha;
	}
	return nodo;

}

/*
Pre: Recibe un arbol no vacio, un nodo al mismo con dos hijos, el padre de ese nodo y la rama que sigue el nodo.
Post: Devuelve 0 si pudo borrar el elemento que recibe o -1 si no pudo
*/
int nodo_borrar_con_2_hijos(abb_t* arbol,nodo_abb_t* nodo_actual,nodo_abb_t* padre_nodo_actual,int rama) {

	nodo_abb_t* nodo_reemplazo = nodo_mayor_de_los_menores(nodo_actual->izquierda);

	void* elemento_aux = nodo_actual->elemento;
	nodo_actual->elemento = nodo_reemplazo->elemento;
	nodo_reemplazo->elemento = elemento_aux;

	if(padre_nodo_actual == NULL) {
		arbol->nodo_raiz->elemento = nodo_actual->elemento;
	}
	/*if(nodo_reemplazo->izquierda != NULL) {
		void* elemento_aux = nodo_reemplazo->elemento;
		nodo_reemplazo->elemento = nodo_reemplazo->izquierda->elemento;
		nodo_reemplazo->izquierda->elemento = elemento_aux;
		
		if(arbol->destructor) {
			arbol->destructor(nodo_reemplazo->izquierda->elemento);
			nodo_reemplazo->izquierda->elemento = NULL;
			nodo_reemplazo->izquierda = NULL;
			free(nodo_reemplazo->izquierda);
			return EXITO;
		}

	}*/
	if(arbol->destructor) {
		arbol->destructor(nodo_reemplazo->elemento);
		nodo_reemplazo->elemento = NULL;
		nodo_reemplazo = NULL;
		free(nodo_reemplazo);
		return EXITO;
	}
	return ERROR;

}

/*
Pre: Recibe un arbol no vacio, un nodo al mismo, el elemento que contiene, el padre de ese nodo y la rama que sigue el nodo.
Post: Devuelve 0 si pudo borrar el elemento que recibe o -1 si no pudo
*/
int arbol_borrar_aux(abb_t* arbol, nodo_abb_t* padre_nodo_actual, nodo_abb_t* nodo_actual, void* elemento, int rama) {

	int comparador = arbol->comparador(nodo_actual->elemento, elemento);

	if (comparador == 0) { // encontro el elemento. Ahora me fijo si es raiz, si tiene 1 hijo, 2 o ninguno (nodo hoja)
		//caso nodo hoja -- > no tiene hijos
		if((nodo_actual->izquierda == NULL) && (nodo_actual->derecha == NULL)) {
			//caso que es raiz el nodo que se quiere borrar y ese nodo no tiene hijos 
			if(padre_nodo_actual == NULL) {
				arbol->nodo_raiz = NULL;
			}
			//caso que es el hijo izq el nodo que se quiere borrar y ese nodo no tiene hijos 
			else if(rama == 1) {
				padre_nodo_actual->izquierda = NULL;
			}
			//caso que es el hijo der el nodo que se quiere borrar y ese nodo no tiene hijos 
			else if(rama == -1) {
				padre_nodo_actual->derecha = NULL;
			}
			if(arbol->destructor) {
				arbol->destructor(nodo_actual->elemento);
				free(nodo_actual);
				return EXITO;
			}
		}
		//caso nodo que no es hoja --- > si tiene un solo hijo
		else if(((nodo_actual->izquierda == NULL) && (nodo_actual->derecha != NULL)) || ((nodo_actual->izquierda != NULL) && (nodo_actual->derecha == NULL))) {
			return nodo_borrar_con_1_hijo(arbol,nodo_actual,padre_nodo_actual,rama);
		}
		//caso nodo que es hoja --- > si tiene dos hijos
		else if((nodo_actual->izquierda != NULL) && (nodo_actual->derecha != NULL)) {
			return nodo_borrar_con_2_hijos(arbol,nodo_actual,padre_nodo_actual,rama);
		}	
	}
	// si todavia no encontro el elemento y el comparador es 1. Me tengo que ir para la izq.
	else if(comparador == 1) {
		return arbol_borrar_aux(arbol,nodo_actual,nodo_actual->izquierda,elemento,1);
	}
	// si todavia no encontro el elemento y el comparador es -1. Me tengo que ir para la der.
	else if(comparador == -1) {
		return arbol_borrar_aux(arbol,nodo_actual,nodo_actual->derecha,elemento,-1);
	}
	return ERROR; // en caso de que no se haya podido hacer ninguna accion

}

/*
Pre: Recibe un arbol no NULL, un nodo al mismo y un elemento para insertar en el arbol
Post: Devuelve el elemento que se buscaba o NULL si no esta en el arbol
*/
void* arbol_buscar_aux(abb_t* arbol, nodo_abb_t* nodo, void* elemento) {

	int comparador = 2;

	if(nodo != NULL) {
		comparador = arbol->comparador(nodo->elemento, elemento);
	}
	if(comparador == 0) {
		return elemento;
	}
	if(comparador == 1) {
		return arbol_buscar_aux(arbol, nodo->izquierda, elemento);
	}
	if(comparador == -1) {
		return arbol_buscar_aux(arbol, nodo->derecha, elemento);
	}
	return NULL;

}

/*
Pre: Recibe un ABB, un nodo a ese ABB, un array para guardar los elementos de los nodos recibidos por parametro, un tamanio_array que es el tope del array y un contador. Recorre el arbol con un recorrido inorden
Post: Devuelve la cantidad de elementos que fueron almacenados en el array
*/
size_t arbol_recorrido_inorden_aux(abb_t* arbol,nodo_abb_t* nodo,void** array,size_t tamanio_array, size_t* contador){

	if((nodo != NULL) && ((*contador) < tamanio_array)) {
		arbol_recorrido_inorden_aux(arbol, nodo->izquierda, array, tamanio_array, contador); 
		if(((*contador) < tamanio_array) && (nodo->elemento != NULL)) {
			array[*contador] = nodo->elemento;
			(*contador)++;
		}
		arbol_recorrido_inorden_aux(arbol, nodo->derecha, array, tamanio_array, contador);
	}
	return (*contador);

}

/*
Pre: Recibe un ABB, un nodo a ese ABB, un array para guardar los elementos de los nodos recibidos por parametro, un tamanio_array que es el tope del array y un contador. Recorre el arbol con un recorrido preorden
Post: Devuelve la cantidad de elementos que fueron almacenados en el array
*/
size_t arbol_recorrido_preorden_aux(abb_t* arbol,nodo_abb_t* nodo, void** array, size_t tamanio_array, size_t* contador) {

	if((nodo != NULL) && ((*contador) < tamanio_array)) {
		if(((*contador) < tamanio_array) && (nodo->elemento != NULL)) {
			array[*contador] = nodo->elemento;
			(*contador)++;
		}
		arbol_recorrido_preorden_aux(arbol, nodo->izquierda, array, tamanio_array, contador);
		arbol_recorrido_preorden_aux(arbol, nodo->derecha, array, tamanio_array, contador);
	}
	return (*contador);

}

/*
Pre: Recibe un ABB, un nodo a ese ABB, un array para guardar los elementos de los nodos recibidos por parametro, un tamanio_array que es el tope del array y un contador. Recorre el arbol con un recorrido postorden
Post: Devuelve la cantidad de elementos que fueron almacenados en el array
*/
size_t arbol_recorrido_postorden_aux(abb_t* arbol,nodo_abb_t* nodo, void** array, size_t tamanio_array, size_t* contador) {

	if((nodo != NULL) && ((*contador) < tamanio_array)) {
		arbol_recorrido_postorden_aux(arbol, nodo->izquierda, array, tamanio_array, contador);
		arbol_recorrido_postorden_aux(arbol, nodo->derecha, array, tamanio_array, contador);
		if(((*contador) < tamanio_array) && (nodo->elemento != NULL)) {
			array[*contador] = nodo->elemento;
			(*contador)++;
		}
	}
	return (*contador);

}

/*
Pre: Recorre el arbol con un recorrido inorden
Post: Devuelve la cantidad de elementos recorridos
*/
size_t arbol_recorrer_inorden(nodo_abb_t* nodo,bool (*funcion)(void*, void*),void* extra, size_t* contador, bool* encontrado){

	if((nodo != NULL) && (*encontrado == false)) {
		arbol_recorrer_inorden(nodo->izquierda, funcion, extra, contador, encontrado);
		if(*encontrado == false) {
			if(funcion(nodo->elemento, extra) == true) {
				(*encontrado) = true;
				return (*contador);
			}
		}
		(*contador)++;
		arbol_recorrer_inorden(nodo->derecha, funcion, extra, contador, encontrado);
	}
	return (*contador);

}

/*
Pre: Recorre el arbol con un recorrido preorden
Post: Devuelve la cantidad de elementos recorridos
*/
size_t arbol_recorrer_preorden(nodo_abb_t* nodo,bool (*funcion)(void*, void*),void* extra, size_t* contador){

	if(nodo != NULL ) { 
		if(funcion(nodo->elemento, extra) == true) {
			return (*contador);
		}
		(*contador)++;
		arbol_recorrer_preorden(nodo->izquierda, funcion, extra, contador);
		arbol_recorrer_preorden(nodo->derecha, funcion, extra, contador);
	}
	return (*contador);

}

/*
Pre: Recorre el arbol con un recorrido postorden
Post: Devuelve la cantidad de elementos recorridos
*/

size_t arbol_recorrer_postorden(nodo_abb_t* nodo,bool (*funcion)(void*, void*),void* extra, size_t* contador, bool* encontrado){

	if((nodo != NULL) && (*encontrado == false)) {
		arbol_recorrer_postorden(nodo->izquierda, funcion, extra, contador, encontrado);
		arbol_recorrer_postorden(nodo->derecha, funcion, extra, contador,encontrado);
		if(*encontrado == false) {
			if(funcion(nodo->elemento, extra) == true) {
				(*encontrado) = true;
				return (*contador);
			}
			(*contador)++;
		}
	}
	return (*contador);

}

// -----------------------------------------------------------------------------------
// -----------------------------FUNCIONES PUBLICAS------------------------------------
// -----------------------------------------------------------------------------------

abb_t* arbol_crear(abb_comparador comparador, abb_liberar_elemento destructor) {

	if(comparador == NULL) {
		return NULL;
	}
	abb_t* arbol_nuevo = NULL;
	arbol_nuevo = malloc(sizeof(abb_t));
	if(!arbol_nuevo) {
		return NULL;
	}
	arbol_nuevo->nodo_raiz = NULL;
	arbol_nuevo->comparador = comparador;
	arbol_nuevo->destructor = destructor;
	return arbol_nuevo;

}

int arbol_insertar(abb_t* arbol, void* elemento) {

	if(arbol == NULL) {
		return ERROR;
	}
	if(arbol_vacio(arbol) == true) {
		nodo_abb_t* nodo_nuevo = arbol_nodo_crear(elemento);
		if(nodo_nuevo == NULL) {
			return ERROR;
		}
		arbol->nodo_raiz = nodo_nuevo;
		return EXITO;
	}
	return arbol_insertar_aux(arbol, arbol->nodo_raiz, elemento);

}

int arbol_borrar(abb_t* arbol, void* elemento) {

	if((arbol_vacio(arbol) == true) || (arbol_buscar(arbol,elemento) == NULL)) {
		return ERROR;
	}
	return arbol_borrar_aux(arbol, NULL, arbol->nodo_raiz, elemento, 0);

}

void* arbol_buscar(abb_t* arbol, void* elemento) {

	if((arbol_vacio(arbol) == true) || (arbol->comparador == NULL) || (elemento == NULL)) {
		return NULL;
	}
	return arbol_buscar_aux(arbol, arbol->nodo_raiz, elemento);

}


void* arbol_raiz(abb_t* arbol) {

	if(arbol_vacio(arbol) == true) {
		return NULL;
	}
	return (arbol->nodo_raiz->elemento);

}

bool arbol_vacio(abb_t* arbol) {

	if((arbol == NULL) || (arbol->nodo_raiz == NULL)) {
		return true;
	}
	return false;

}

size_t arbol_recorrido_inorden(abb_t* arbol, void** array, size_t tamanio_array) {

	if((arbol_vacio(arbol) == true) || (array == NULL)) {
		return VACIO;
	}
	size_t contador = 0;
	return arbol_recorrido_inorden_aux(arbol, arbol->nodo_raiz, array, tamanio_array, &contador);

}

size_t arbol_recorrido_preorden(abb_t* arbol, void** array, size_t tamanio_array) {

	if((arbol_vacio(arbol) == true) || (array == NULL)) {
		return VACIO;
	}
	size_t contador = 0;
	return arbol_recorrido_preorden_aux(arbol, arbol->nodo_raiz, array, tamanio_array, &contador);

}

size_t arbol_recorrido_postorden(abb_t* arbol, void** array, size_t tamanio_array) {

	if((arbol_vacio(arbol) == true) || (array == NULL)) {
		return VACIO;
	}
	size_t contador = 0;
	return arbol_recorrido_postorden_aux(arbol, arbol->nodo_raiz, array, tamanio_array, &contador);

}

void arbol_destruir(abb_t* arbol) {

	if(!arbol) {
		return;
	}
	if(arbol->nodo_raiz) {
		arbol_nodo_destruir(arbol->nodo_raiz,arbol->destructor);
	}
	free(arbol);

}

size_t abb_con_cada_elemento(abb_t* arbol, int recorrido, bool (*funcion)(void*, void*), void* extra) {

	size_t contador = 0;
	bool encontrado = false;

	if((arbol_vacio(arbol) == true) || (funcion == NULL)) {
		return VACIO;
	}

	if(recorrido == ABB_RECORRER_INORDEN) {
		return arbol_recorrer_inorden(arbol->nodo_raiz, funcion, extra, &contador, &encontrado);
	}

	else if(recorrido == ABB_RECORRER_PREORDEN) {
		return arbol_recorrer_preorden(arbol->nodo_raiz, funcion, extra, &contador);
	}

	else if(recorrido == ABB_RECORRER_POSTORDEN) {
		return arbol_recorrer_postorden(arbol->nodo_raiz, funcion, extra, &contador, &encontrado);
	}

	return VACIO;

}